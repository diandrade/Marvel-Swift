//
//  ViewController+UITableView.swift
//  Marvel
//
//  Created by iOS Lab on 22/06/24.
//
import UIKit

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        10
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        150
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
             return tableView.dequeueReusableCell(withIdentifier: "heroCell", for: indexPath)
        } 
        return tableView.dequeueReusableCell(withIdentifier: "identi", for: indexPath)
    }
}

extension ViewController: UITableViewDelegate {
    
}
